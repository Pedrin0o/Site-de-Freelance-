// Dados mockados para as categorias
const categories = [
    { id: 1, name: "Design Gráfico", icon: "fa-paint-brush" },
    { id: 2, name: "Marketing Digital", icon: "fa-bullseye" },
    { id: 3, name: "Inteligência Artificial", icon: "fa-robot" },
    { id: 4, name: "Negócios", icon: "fa-briefcase" },
    { id: 5, name: "Escrita e Tradução", icon: "fa-pen-fancy" },
    { id: 6, name: "Música e Áudio", icon: "fa-music" },
    { id: 7, name: "Programação e Tecnologia", icon: "fa-code" },
    { id: 8, name: "Vídeo e Animação", icon: "fa-video" },
    { id: 9, name: "Estilo de Vida", icon: "fa-heart" },
    { id: 10, name: "Publicidade", icon: "fa-ad" }
];

// Dados mockados para os serviços
const services = [
    {
        id: 1,
        title: "Criação de Logo Profissional",
        category: "Design Gráfico",
        description: "Vou criar um logo único e profissional para sua marca",
        price: 150,
        rating: 4.9,
        reviews: 128,
        seller: {
            name: "Ana Design",
            avatar: "https://randomuser.me/api/portraits/women/44.jpg"
        },
        image: "https://source.unsplash.com/random/400x300/?logo,design"
    },
    {
        id: 2,
        title: "Campanha de Facebook Ads",
        category: "Marketing Digital",
        description: "Gerenciamento completo de campanhas no Facebook e Instagram",
        price: 300,
        rating: 4.8,
        reviews: 95,
        seller: {
            name: "Marketing Pro",
            avatar: "https://randomuser.me/api/portraits/men/32.jpg"
        },
        image: "https://source.unsplash.com/random/400x300/?facebook,ads"
    },
    {
        id: 3,
        title: "Chatbot para WhatsApp",
        category: "Inteligência Artificial",
        description: "Desenvolvo um chatbot inteligente para seu WhatsApp Business",
        price: 500,
        rating: 5.0,
        reviews: 64,
        seller: {
            name: "Tech Solutions",
            avatar: "https://randomuser.me/api/portraits/men/75.jpg"
        },
        image: "https://source.unsplash.com/random/400x300/?chatbot,ai"
    },
    {
        id: 4,
        title: "Plano de Negócios",
        category: "Negócios",
        description: "Elaboro um plano de negócios completo para sua startup",
        price: 250,
        rating: 4.7,
        reviews: 42,
        seller: {
            name: "Business Consult",
            avatar: "https://randomuser.me/api/portraits/women/68.jpg"
        },
        image: "https://source.unsplash.com/random/400x300/?business,plan"
    }
];