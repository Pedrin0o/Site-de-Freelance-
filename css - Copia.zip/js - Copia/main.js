document.addEventListener('DOMContentLoaded', function() {
    // Carrega as categorias
    loadCategories();
    
    // Carrega os serviços
    loadServices();
    
    // Configura o menu mobile
    setupMobileMenu();
});

function loadCategories() {
    const categoryGrid = document.getElementById('categoryGrid');
    
    categories.forEach(category => {
        const categoryCard = document.createElement('div');
        categoryCard.className = 'category-card';
        categoryCard.innerHTML = `
            <i class="fas ${category.icon}"></i>
            <h4>${category.name}</h4>
        `;
        categoryGrid.appendChild(categoryCard);
    });
}

function loadServices() {
    const serviceGrid = document.getElementById('serviceGrid');
    
    services.forEach(service => {
        const serviceCard = document.createElement('div');
        serviceCard.className = 'service-card';
        serviceCard.innerHTML = `
            <div class="service-image" style="background-image: url('${service.image}')"></div>
            <div class="service-info">
                <h3 class="service-title">${service.title}</h3>
                <div class="service-seller">
                    <img src="${service.seller.avatar}" alt="${service.seller.name}">
                    <span>${service.seller.name}</span>
                </div>
                <div class="service-rating">
                    ${generateStarRating(service.rating)} (${service.reviews})
                </div>
                <div class="service-price">A partir de R$${service.price.toFixed(2)}</div>
            </div>
        `;
        serviceGrid.appendChild(serviceCard);
    });
}

function generateStarRating(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    let stars = '';
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }
    
    return stars;
}

function setupMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const nav = document.querySelector('.nav');
    
    menuBtn.addEventListener('click', () => {
        nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
    });
    
    // Fechar menu ao clicar em um link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            nav.style.display = 'none';
        });
    });
}